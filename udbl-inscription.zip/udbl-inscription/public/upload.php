<?php

// Vérifier si un fichier a été téléchargé
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['document'])) {
    $dossierCible = __DIR__ . '/../uploads/';
    $nomFichier = basename($_FILES['document']['name']);
    $cheminFichier = $dossierCible . $nomFichier;

    // Vérifier et déplacer le fichier
    if (move_uploaded_file($_FILES['document']['tmp_name'], $cheminFichier)) {
        echo json_encode(['message' => 'Fichier téléchargé avec succès']);
    } else {
        echo json_encode(['message' => 'Erreur lors du téléchargement du fichier']);
    }
} else {
    echo json_encode(['message' => 'Aucun fichier téléchargé']);
}