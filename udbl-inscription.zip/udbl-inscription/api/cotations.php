{
    "etudiant_id": 1,
    "cours_id": 2,
    "note": 85.5
}