<?php

// Charger la configuration
$config = require __DIR__ . '/../config/config.php';
$db = new PDO("sqlite:" . $config['db']['database']);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Définir le type de contenu en JSON
header('Content-Type: application/json');

// Récupérer la méthode HTTP
$methode = $_SERVER['REQUEST_METHOD'];

switch ($methode) {
    case 'POST':
        // Ajouter un étudiant
        $donnees = json_decode(file_get_contents('php://input'), true);
        $requete = $db->prepare("INSERT INTO etudiants (nom, email, telephone) VALUES (:nom, :email, :telephone)");
        $requete->execute([
            ':nom' => $donnees['nom'],
            ':email' => $donnees['email'],
            ':telephone' => $donnees['telephone'],
        ]);
        echo json_encode(['message' => 'Étudiant inscrit avec succès']);
        break;

    case 'GET':
        // Récupérer la liste des étudiants
        $requete = $db->query("SELECT * FROM etudiants");
        echo json_encode($requete->fetchAll(PDO::FETCH_ASSOC));
        break;

    default:
        http_response_code(405);
        echo json_encode(['message' => 'Méthode non autorisée']);
        break;
}
