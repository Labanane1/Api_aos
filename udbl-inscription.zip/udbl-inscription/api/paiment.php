<?php
// paiment.php

// Vérification des méthodes HTTP
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Méthode non autorisée
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}

// Récupération des données envoyées
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['amount']) || !isset($data['user_id'])) {
    http_response_code(400); // Mauvaise requête
    echo json_encode(['error' => 'Paramètres manquants']);
    exit;
}

// Variables
$amount = $data['amount'];
$user_id = $data['user_id'];

// Exemple de logique de traitement du paiement
try {
    // Connexion à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=udbl', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Insertion du paiement dans la base de données
    $stmt = $pdo->prepare('INSERT INTO payments (user_id, amount, payment_date) VALUES (:user_id, :amount, NOW())');
    $stmt->execute([
        ':user_id' => $user_id,
        ':amount' => $amount
    ]);

    // Réponse en cas de succès
    http_response_code(201); // Ressource créée
    echo json_encode(['success' => 'Paiement enregistré avec succès']);
} catch (PDOException $e) {
    // Gestion des erreurs de base de données
    http_response_code(500); // Erreur interne du serveur
    echo json_encode(['error' => 'Erreur serveur : ' . $e->getMessage()]);
}
?>