<?php

// Charger la configuration
$config = require __DIR__ . '/../config/config.php';
$db = new PDO("sqlite:" . $config['db']['database']);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Définir le type de contenu en JSON
header('Content-Type: application/json');

// Récupérer la méthode HTTP
$methode = $_SERVER['REQUEST_METHOD'];

switch ($methode) {
    case 'GET':
        // Récupérer les résultats des étudiants
        $requete = $db->query("SELECT etudiants.nom, cours.nom AS cours, cotations.note 
                               FROM cotations 
                               JOIN etudiants ON cotations.etudiant_id = etudiants.id 
                               JOIN cours ON cotations.cours_id = cours.id");
        echo json_encode($requete->fetchAll(PDO::FETCH_ASSOC));
        break;

    default:
        http_response_code(405);
        echo json_encode(['message' => 'Méthode non autorisée']);
        break;
}