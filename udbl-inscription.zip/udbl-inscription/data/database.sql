-- Création des tables pour SQLite

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    course_name TEXT NOT NULL,
    inscription_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Exemple d'insertion de données
INSERT INTO users (username, password, email) VALUES
('john_doe', 'hashed_password', 'john@example.com'),
('jane_doe', 'hashed_password', 'jane@example.com');

INSERT INTO inscriptions (user_id, course_name) VALUES
(1, 'Mathematics 101'),
(2, 'Physics 202');