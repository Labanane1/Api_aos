<?php
// UDBL Configuration Example

return [
    'database' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'udbl_database',
        'user' => 'root',
        'password' => '',
    ],
    'app' => [
        'url' => 'http://localhost/udbl-inscription',
        'environment' => 'development', // Options: development, production
        'debug' => true,
    ],
    'mail' => [
        'host' => 'smtp.mailtrap.io',
        'port' => 2525,
        'username' => 'luboya',
        'password' => '',
        'encryption' => 'tls', // Options: tls, ssl
        'from_address' => 'no-reply@udbl.com',
        'from_name' => 'UDBL Support',
    ],
];